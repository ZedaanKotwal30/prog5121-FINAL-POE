/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.createaccount;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class ManagerTaskTest {
    
    public ManagerTaskTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of populateTestData method, of class ManagerTask.
     */
    @Test
    public void testPopulateTestData() {
        System.out.println("populateTestData");
        ManagerTask.populateTestData();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayDoneTasks method, of class ManagerTask.
     */
    @Test
    public void testDisplayDoneTasks() {
        System.out.println("displayDoneTasks");
        ManagerTask.displayDoneTasks();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of taskWithLongestDuration method, of class ManagerTask.
     */
    @Test
    public void testTaskWithLongestDuration() {
        System.out.println("taskWithLongestDuration");
        ManagerTask.taskWithLongestDuration();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchTask method, of class ManagerTask.
     */
    @Test
    public void testSearchTask() {
        System.out.println("searchTask");
        String taskName = "";
        ManagerTask.searchTask(taskName);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of taskByDeveloper method, of class ManagerTask.
     */
    @Test
    public void testTaskByDeveloper() {
        System.out.println("taskByDeveloper");
        String developerName = "";
        ManagerTask.taskByDeveloper(developerName);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deleteTask method, of class ManagerTask.
     */
    @Test
    public void testDeleteTask() {
        System.out.println("deleteTask");
        String taskName = "";
        ManagerTask.deleteTask(taskName);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayAllTasks method, of class ManagerTask.
     */
    @Test
    public void testDisplayAllTasks() {
        System.out.println("displayAllTasks");
        ManagerTask.displayAllTasks();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
