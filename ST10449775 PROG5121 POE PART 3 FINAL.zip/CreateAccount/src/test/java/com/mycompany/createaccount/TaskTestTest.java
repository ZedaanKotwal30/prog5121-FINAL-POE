/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.createaccount;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class TaskTestTest {
    
    public TaskTestTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of setUpClass method, of class TaskTest.
     */
    @Test
    public void testSetUpClass() throws Exception {
        System.out.println("setUpClass");
        TaskTest.setUpClass();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of tearDownClass method, of class TaskTest.
     */
    @Test
    public void testTearDownClass() throws Exception {
        System.out.println("tearDownClass");
        TaskTest.tearDownClass();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setUp method, of class TaskTest.
     */
    @Test
    public void testSetUp() throws Exception {
        System.out.println("setUp");
        TaskTest instance = new TaskTest();
        instance.setUp();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of tearDown method, of class TaskTest.
     */
    @Test
    public void testTearDown() throws Exception {
        System.out.println("tearDown");
        TaskTest instance = new TaskTest();
        instance.tearDown();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testChechTaskDescription method, of class TaskTest.
     */
    @Test
    public void testTestChechTaskDescription() {
        System.out.println("testChechTaskDescription");
        TaskTest instance = new TaskTest();
        instance.testChechTaskDescription();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testPrintTaskDetails method, of class TaskTest.
     */
    @Test
    public void testTestPrintTaskDetails() {
        System.out.println("testPrintTaskDetails");
        TaskTest instance = new TaskTest();
        instance.testPrintTaskDetails();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testGetTaskStatus method, of class TaskTest.
     */
    @Test
    public void testTestGetTaskStatus() {
        System.out.println("testGetTaskStatus");
        TaskTest instance = new TaskTest();
        instance.testGetTaskStatus();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testSetTaskStatus method, of class TaskTest.
     */
    @Test
    public void testTestSetTaskStatus() {
        System.out.println("testSetTaskStatus");
        TaskTest instance = new TaskTest();
        instance.testSetTaskStatus();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testGetTaskID method, of class TaskTest.
     */
    @Test
    public void testTestGetTaskID() {
        System.out.println("testGetTaskID");
        TaskTest instance = new TaskTest();
        instance.testGetTaskID();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testSetTaskID method, of class TaskTest.
     */
    @Test
    public void testTestSetTaskID() {
        System.out.println("testSetTaskID");
        TaskTest instance = new TaskTest();
        instance.testSetTaskID();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testSetTaskDuration method, of class TaskTest.
     */
    @Test
    public void testTestSetTaskDuration() {
        System.out.println("testSetTaskDuration");
        TaskTest instance = new TaskTest();
        instance.testSetTaskDuration();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testGetDeveloperDetails method, of class TaskTest.
     */
    @Test
    public void testTestGetDeveloperDetails() {
        System.out.println("testGetDeveloperDetails");
        TaskTest instance = new TaskTest();
        instance.testGetDeveloperDetails();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testSetDeveloperDetails method, of class TaskTest.
     */
    @Test
    public void testTestSetDeveloperDetails() {
        System.out.println("testSetDeveloperDetails");
        TaskTest instance = new TaskTest();
        instance.testSetDeveloperDetails();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testGetTaskDescription method, of class TaskTest.
     */
    @Test
    public void testTestGetTaskDescription() {
        System.out.println("testGetTaskDescription");
        TaskTest instance = new TaskTest();
        instance.testGetTaskDescription();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testSetTaskDescription method, of class TaskTest.
     */
    @Test
    public void testTestSetTaskDescription() {
        System.out.println("testSetTaskDescription");
        TaskTest instance = new TaskTest();
        instance.testSetTaskDescription();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testGetTaskName method, of class TaskTest.
     */
    @Test
    public void testTestGetTaskName() {
        System.out.println("testGetTaskName");
        TaskTest instance = new TaskTest();
        instance.testGetTaskName();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testSetTaskNumber method, of class TaskTest.
     */
    @Test
    public void testTestSetTaskNumber() {
        System.out.println("testSetTaskNumber");
        TaskTest instance = new TaskTest();
        instance.testSetTaskNumber();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testSetTakStatus method, of class TaskTest.
     */
    @Test
    public void testTestSetTakStatus() {
        System.out.println("testSetTakStatus");
        TaskTest instance = new TaskTest();
        instance.testSetTakStatus();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testGetTaskDuration method, of class TaskTest.
     */
    @Test
    public void testTestGetTaskDuration() {
        System.out.println("testGetTaskDuration");
        TaskTest instance = new TaskTest();
        instance.testGetTaskDuration();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
